<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    protected $generalModel;
    protected $userModel;
    public function __construct()
    {
        $this->generalModel = new \App\Models\GeneralModel();
        $this->userModel = new \App\Models\UserModel();
    }
    public function home() {  
        return view('dashboard');
    }
    public function ajax_load_Deptchart(Request $request) {
		$data['val'] = $request->get('val');
		return view('api/load_Deptchart',$data);
    }
    public function new_request() {
        return view('NewEntry');
    }
    public function newCreation(Request $request) {  
        // print_r("Session::get('empuname')");
        // exit;
        $data['req_type'] = $request->get('req_type');		
        $data['proj_title'] = $request->get('proj_title');
        $data['existing_name'] = $request->get('existing_name');
        $data['cur_process'] = $request->get('cur_process');
        $data['pros_process'] = $request->get('pros_process');
        $data['sel_4fp'] = $request->get('sel_4fp');
        $data['outcome'] = $request->get('outcome');
        $data['editId'] = $request->get('editId');
        
                        
        if(isset($_FILES['docu']) && $_FILES['docu']['name']!='') {  
            $file = explode('.',strtolower($_FILES['docu']['name']));     
            $ary = end($file); 
            $tmp = $_FILES['docu']['tmp_name'];
            $filename = $file[0]."_".date('d-M-Y').".".$ary;
            $alert_file = 'Fileupload/'.$filename;
            $upl = move_uploaded_file($_FILES['docu']['tmp_name'],$alert_file);
            if($upl){	
                $data['upload_doc'] = $filename;
            }
        }  
        else {
            $data['upload_doc'] ='';
        }
    
        if($request->get('req_type')) {
            
            $Res= $this->generalModel->addnew_Creation($data);
            if ($Res == 1) {
            $data['error_message'] = "Successfully inserted";
            } else {
                $data['error_message'] = 'Error';
            }
            
        }
        echo ($data['error_message']); 
        exit(); 
    }
    public function ajax_loadproject_title(Request $request) { 
        $title = $request->get('title');
        $data['Proj_List'] = $this->generalModel->getproject_list($title); 
    }
    public function myreq() {
        return view('Master');
    }
    public function ajaxload_myrecords(Request $request)
    {
        $data['page'] = request()->segment(3);

        switch ($data['page']) {
            case 1:
                if (isset($_POST)) {
                    $data['radiotype'] = $request->get('radiotype');
                    $data['priority'] = $request->get('priority');
                }
                $data['list'] = $this->generalModel->getMyrecords($data);
                break;

            case 2:
                $data['list'] = $this->generalModel->getHodrecords($data);
                break;

            case 4:
                $data['list'] = $this->generalModel->getFeasirecords($data);
                break;

            case 5:
                $data['list'] = $this->generalModel->getItHeadrecords($data);
                break;

            case 6:
                $data['list'] = $this->generalModel->getTargetdate($data);
                break;

            case 7:
                $data['list'] = $this->generalModel->getUATdata($data);
                break;
        }
        return view('api/load_my_request', $data);
    }
    public function viewcreation() {
       return view('viewEntry');
    }
    public function hod() {
        return view('Master');
    }
    public function feasi() {
        return view('Master');
    }
    public function feasiview() {
        return view('viewEntry');
    }
    public function getApproval(Request $request) {   // print_r($_POST); exit;
        $data['pages'] = $request->get('pages');
        
        switch($data['pages'])  { 
        case 'hodapprove' :  
            $data['sts'] = $request->get('sts');		
            $data['cmts'] = $request->get('cmts');
            $data['id'] = $request->get('id');
            $data['base_url'] = $request->get('base_url');
            
            if($request->get('sts')) {
                // $this->form_validation->set_rules('sts', 'Status', 'required');

                $validator = Validator::make($request->all(), [
                    'sts' => 'required',
                ]);
                    
                if ($validator->fails()) {
                    $data['error_message'] = $validator;
                } 
                else {
                    $Res= $this->generalModel->getHOD_Approval($data);
                    if ($Res == 1) {
                        $data['error_message'] = 1;
                    } 
                    else {
                        $data['error_message'] = 'Error !!!';
                    }
                }
            }
            echo ($data['error_message']); 
            exit();
            
        break; 
        
        case 'feasiview' :
            $data['sts'] = $request->get('sts');		
            $data['cmts'] = $request->get('cmts');
            $data['id'] = $request->get('id');
            $data['devp'] = $request->get('devp');
            $data['dev_days'] = $request->get('dev_days');
            $data['project_date'] = $request->get('project_date');		
            $data['enddate'] = $request->get('enddate');	
            $data['base_url'] = $request->get('base_url');
            
            if($request->get('sts')) {
                // $this->form_validation->set_rules('sts', 'Status', 'required');
                $validator = Validator::make($request->all(), [
                    'sts' => 'required',
                ]);
                    
                if ($validator->fails()) {
                    $data['error_message'] = $validator;
                } 
                else {
                    $Res= $this->generalModel->getFeasibility($data);
                    if ($Res == 1) {
                        $data['error_message'] = 1;
                    } 
                    else {
                        $data['error_message'] = 'Error !!!';
                    }
                }
            }
            echo ($data['error_message']); 
            exit();
        break;
        
        case 'itapprove' :
            $data['sts'] = $request->get('sts');		
            $data['cmts'] = $request->get('cmts');
            $data['id'] = $request->get('id');
            $data['itprio'] = $request->get('itprio');
            $data['base_url'] = $request->get('base_url');
            
            if($request->get('sts')) {
                // $this->form_validation->set_rules('sts', 'Status', 'required');
                $validator = Validator::make($request->all(), [
                    'sts' =>  'required',
                ]);
                if ($validator->fails()) {
                    $data['error_message'] = $validator;
                } 
                else {
                    $Res= $this->generalModel->geItHeadApproval($data);
                    if ($Res == 1) {
                        $data['error_message'] = 1;
                    } 
                    else {
                        $data['error_message'] = 'Error !!!';
                    }
                }
            }
            echo ($data['error_message']); 
            exit();
        break;
        
        case 'projdate' :
            $data['startdate'] = $request->get('startdate');		
            $data['sts'] = $request->get('sts');		
            $data['cmts'] = $request->get('cmts');		
            $data['id'] = $request->get('id');
            $data['base_url'] = $request->get('base_url');
            
            if($request->get('sts')) {
                // $this->form_validation->set_rules('sts', 'Status', 'required');
                $validator = Validator::make($request->all(), [
                    'sts' => 'required',
                ]);
                if ($validator->fails()) {
                    $data['error_message'] = $validator;
                } 
                else {
                    $Res= $this->generalModel->geTentativeDate($data);
                    if ($Res == 1) {
                        $data['error_message'] = 1;
                    } 
                    else {
                        $data['error_message'] = 'Error !!!';
                    }
                }
            }
            echo ($data['error_message']); 
            exit();
        break;
        
        
        }
        
    }
    public function hodapprove() {  
        return view('viewEntry');
    }
    public function editcreation() {
       return view('NewEntry');
    }
    public function ithead() {
        return view('Master');	
    }
    public function itapprove() {
        return view('viewEntry');
    }
    public function tentdate() {
        return view('Master');	
    }
    public function projdate() {
        return view('viewEntry');
    }
    public function UAT() {
        return view('Master');	
    }
    public function report() {
        return view('Master');
    }
    public function ajaxLoadreports(Request $request) {  //print_r($_POST); exit;  
        if(isset($_POST)) {
            $data['radiotype'] = $request->get('radiotype');     				
            $data['stats'] = $request->get('stats');           
            $data['dept'] = $request->get('dept');           
        }
        $data['records'] = $this->generalModel->getAllrecords($data);
        return view('api/load_my_report',$data);
    }
    public function load_Remarks(Request $request) {
        $data['id'] = $request->get('id');  
        $data['page'] = $request->get('page');  
        return view('Remark',$data);
    }
    public function reportview() {
        return view('viewEntry');
    }
    public function portal_access_request() {
        return view('NewPortalAccessEntry');
    }
    public function my_access_request_list(){
        $data['p_access_list'] = $this->generalModel->get_mycreation();
        $data['pageTitle'] = 'My Creation';
       return view('portal_access_list',$data);
    }
    public function portal_access_view($id,$urisegment){
        $data['access_id'] = $id;
        $data['urisegment'] = $urisegment;
        $cmaster = $this->generalModel->getRecords('comment_master_for_access_request','query_id',$id);
        $data['commentsDetails'] = $cmaster;
        $rdetails = $this->generalModel->getRecords('portal_access_request','access_id',$id);
        $data['rqDetails'] = $rdetails;
        return view('ajax_view_portal_access',$data);
    }
    public function submit_to_approve(Request $request){
        $portal_list = $request->get('portal_name');
        $remarks = $request->get('remarks');
        $route_to = $request->get('route_to');
        $data['portal_list'] =  $portal_list;
        $data['remarks'] =  $remarks;
        $data['route_to'] =  $route_to;
        $data['is_active'] =  1;
        $data['status'] =  'S';
        $data['created_by'] =  session()->get('empid');
        $data['created_date'] =  date('Y-m-d H:i:s');
        $last_id = $this->generalModel->createData($data,'portal_access_request');
        
        $data1['query_id'] = $last_id;
        $data1['status'] = 'S';
        $data1['comment'] = 'Submitted';
        $data1['approver_name'] = session()->get('empname');
        $data1['approved_date'] = date("Y-m-d");
        $this->generalModel->createData($data1,'comment_master_for_access_request');
        
        $URL = config('app.site_url');
        $emp = $this->generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.session()->get('empuname').'" ');
            
        $message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been Submitted</div><br>';
        $message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
        $message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
        $message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$data['created_date'].'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$data['portal_list'].'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$emp.'</td></tr>'; 
        $message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">Submitted</td></tr></table>';
        
        $message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
        $message.='<br>&nbsp;';
        $message.='<br><b>Thanks & Regards,</b>';
        $message.='<br>'.session()->get('empname').'';
        $message.='<br>Comstar Automotive Technologies Pvt Ltd.,';
    
        $to = $this->generalModel->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_username = "'.$data['route_to'].'" '); 
        
        $subject ="Portal Access Request - Submitted";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= "From: ".session()->get('empemail'). "\r\n";
        $headers .= "Cc: ".session()->get('empemail'). "\r\n";
        
        echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
        
        $maildata = mail($to,$subject,$message,$headers);  
        // if($maildata) { 
            // return 1; 
        // }
        echo 1;
    }
    public function save_ROApproval(Request $request){
        $edit_id = $request->get('access_id');
        $data['portal_list'] = $request->get('portal_name');
        $data['status'] = $request->get('status');
        $this->generalModel->updateData($data,'portal_access_request','access_id',$edit_id);
        $data1['comment'] = $request->get('cmts');
        $data1['query_id'] = $edit_id;
        $data1['status'] =  $request->get('status');
        $data1['approver_name'] = session()->get('empname');
        $data1['approved_date'] = date("Y-m-d");
        $this->generalModel->createData($data1,'comment_master_for_access_request');
        if($data['status'] == "HA"){
            $text = 'Approved';
        } else {
            $text = 'Rejected';
        }
        
        
        $URL = config('app.site_url');
        $empData = $this->generalModel->getRecords('portal_access_request','access_id',$edit_id);
        $emp = $empData;
        $employee = $this->generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_id = "'.$emp[0]->created_by.'" ');
        $empmail = $this->generalModel->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_id = "'.$emp[0]->created_by.'" ');
            
        $message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been '.$text.' by Ro/HOD</div><br>';
        $message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
        $message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
        $message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$emp[0]->created_date.'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$emp[0]->portal_list.'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$employee.'</td></tr>'; 
        $message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">RO / HOD '.$text.'</td></tr></table>';
        
        $message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
        $message.='<br>&nbsp;';
        $message.='<br><b>Thanks & Regards,</b>';
        $message.='<br>'.session()->get('empname').'';
        $message.='<br>Comstar Automotive Technologies Pvt Ltd.,';
        $toArray = array();
        foreach(config('app.it_approval') as $user){
            $toArray[] = $this->generalModel->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_username = "'.$user.'" '); 
        }
        $to = implode(',',$toArray);
        $subject ="Portal Access Request - ".$text;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= "From: ".session()->get('app.empemail'). "\r\n";
        $headers .= "Cc: ".$empmail. "\r\n";
        
         echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
        
        $maildata = mail($to,$subject,$message,$headers);  
        // if($maildata) { 
            // return 1; 
        // }
        echo 1;
    }
    public function get_approval_list(){
        $data['p_access_list'] = $this->generalModel->get_approval_list();
        $data['pageTitle'] = 'Approval';
        return view('portal_access_list',$data);
    }
    public function get_IT_approval_list(){
        $data['p_access_list'] = $this->generalModel->get_IT_approval_list();
        $data['pageTitle'] = 'IT Approval';
        return view('portal_access_list',$data);
    }
    public function save_ITApproval(Request $request){
        $edit_id = $request->get('access_id');
        $data['status'] = $request->get('status');
        $this->generalModel->updateData($data,'portal_access_request','access_id',$edit_id);
        $data1['comment'] = $request->get('cmts');
        $data1['query_id'] = $edit_id;
        $data1['status'] =  $request->get('status');
        $data1['approver_name'] = session()->get('empname');
        $data1['approved_date'] = date("Y-m-d");
        $this->generalModel->createData($data1,'comment_master_for_access_request');
        
        if($data['status'] == "C"){
            $text = 'Approved';
        } else {
            $text = 'Rejected';
        }
        
        $URL = config('app.site_url');
        $empData = $this->generalModel->getRecords('portal_access_request','access_id',$edit_id);
        $emp = $empData;
        $employee = $this->generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_id = "'.$emp[0]->created_by.'" ');
        $empmail = $this->generalModel->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_id = "'.$emp[0]->created_by.'" ');
            
        $message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been '.$text.' by Portal Team</div><br>';
        $message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
        $message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
        $message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$emp[0]->created_date.'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$emp[0]->portal_list.'</td></tr>';
        $message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$employee.'</td></tr>'; 
        $message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">Portal Team '.$text.'</td></tr></table>';
        
        $message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
        $message.='<br>&nbsp;';
        $message.='<br><b>Thanks & Regards,</b>';
        $message.='<br>'.session()->get('empname').'';
        $message.='<br>Comstar Automotive Technologies Pvt Ltd.,';
        
        $to = $empmail;
        $subject ="Portal Access Request - ".$text;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        $headers .= "From: ".session()->get('empemail'). "\r\n";
        $headers .= "Cc: ".session()->get('empemail'). "\r\n";
        
         echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
        
        $maildata = mail($to,$subject,$message,$headers);  
        // if($maildata) { 
            // return 1; 
        // }
        echo 1;
    }
    public function getReview(Request $request) {   //print_r($_POST); exit;
        $data['id'] = $request->get('id');		
        $data['it_remark'] = $request->get('it_remark');
        $data['base_url'] = $request->get('base_url');
            
        if($request->get('it_remark')) {
            $validator = Validator::make($request->all(), [
                'it_remark' => 'required',
            ]);
            if ($validator->fails()) {
                $data['error_message'] = $validator;
            } 
            else {
                $Res= $this->generalModel->getItReview($data);
                if ($Res == 1) {
                    $data['error_message'] = 1;
                } 
                else {
                    $data['error_message'] = 'Error !!!';
                }
            }
        }
        echo ($data['error_message']); 
        exit();
    }
}
