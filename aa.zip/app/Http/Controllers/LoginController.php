<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    protected $generalModel;
    protected $userModel;
    public function __construct()
    {
        $this->generalModel = new \App\Models\GeneralModel();
        $this->userModel = new \App\Models\UserModel();
    }
    public function login(){
        return view('login');
    }
    public function loginCheck(Request $request){

        $user = $this->userModel->Check_user_exists($request->uname);

        if(count($user)>0){
            $ldaprdn = $request->get('uname', TRUE); 
            $ldappass = $request->get('pwd', TRUE); 	
            // $ldaprdn = $ldaprdn.'@comstarauto.com';   
            // $ldapconn = ldap_connect("portalad") or die("Could not connect to LDAP server.");
            // @$ldapbind = ldap_bind($ldapconn, $ldaprdn, $ldappass);
            // if ($ldapbind) { 
            //     session()->put('uname',$user[0]->cs_emp_username);
            //     Session::put('empuname',$user[0]->cs_emp_username);
            //     Session::put('empid', $user[0]->cs_emp_id);
            //     Session::put('empname',$user[0]->cs_emp_name);
            //     Session::put('empemail',$user[0]->cs_emp_email);
            //     Session::put('empdeptid',$user[0]->cs_emp_dept_id);
            //     Session::put('deptname',$user[0]->cs_emp_dept);
            //     Session::put('hod',$user[0]->cs_emp_hod);
            //     Session::put('emp_hod',$user[0]->cs_emp_hod);
            //     Session::put('emp_ro',$user[0]->cs_emp_ro);
               
            //     Session::save();
            //     echo 1; 
			//     exit;
                
            // } else { 
            //     echo 2;
            // }
            Session::put('empuname',$user[0]->cs_emp_username);
            Session::put('empid', $user[0]->cs_emp_id);
            Session::put('empname',$user[0]->cs_emp_name);
            Session::put('empemail',$user[0]->cs_emp_email);
            Session::put('empdeptid',$user[0]->cs_emp_dept_id);
            Session::put('deptname',$user[0]->cs_emp_dept);
            Session::put('hod',$user[0]->cs_emp_hod);
            Session::put('emp_hod',$user[0]->cs_emp_hod);
            Session::put('emp_ro',$user[0]->cs_emp_ro);
            Session::save();

            echo 1; 
			exit;
        } else {
            echo 3; 
            exit;
        }  
        
    }
    public function logout(){
        Session::flush();

        return redirect('login');
    }
}
