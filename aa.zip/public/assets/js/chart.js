
var chart = Highcharts.chart('container', {    
		
		title: {
			text: 'It Request Status',
				style: {
					color: 'red',
					fontSize:'16px'
				}
		},
		
		chart :{
			type:'column',      // It defines graph type ...... i.e bar chart
		},
		
		legend: {
			enabled: false     // Disable the name shown chart below
		},
	
		xAxis: [{
			categories: [<?php echo implode(',',$category)?>] ,    
		}],
		
		yAxis: [{
			
			labels: { 
				format: '{value} ', 
				style: {
					color: 'red',fontSize:'14px'
				}
			},
			
			lineColor: 'red',
			lineWidth: 1,
			
			title: {
				text: 'Values',
				style: {
					color: 'green',fontSize:'14px'
				}
			}
		}], 
					
		series: [{ 
			data: [<?php echo implode(',',$dataArr);?>],   
		}]
			
	});