		//  **************************   LOGIN PAGE VALIDATION *********************************

//$(document).on('click', '#LogSubBtn', function(e) { 
 
// Onclick event is used once ready function is intialised (onclick is used to refresh ready function and re-load other dom event like onclick, onchange....)

$(function(){  	// $(document).ready(function(){  	While log in this DOM Event should be used 
$("#LoginValidation").validate({

	ignore: 'input[type=hidden], .select2-search__field', // ignore hidden fields
	errorClass: 'validation-error-label',
	successClass: 'validation-valid-label',
		
	highlight: function(element, errorClass) {
		$(element).removeClass(errorClass);
	},
	unhighlight: function(element, errorClass) {
		$(element).removeClass(errorClass);
	},

	errorPlacement: function(error, element) {
		// Styled checkboxes, radios, bootstrap switch
		if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
			if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent().parent().parent() );
			}
			else {
				error.appendTo( element.parent().parent().parent().parent().parent() );
			}
		}
				// Unstyled checkboxes, radios
		else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
			error.appendTo( element.parent().parent().parent() );
		}
			// Input with icons and Select2
		else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
			error.appendTo( element.parent() );
		}
			// Inline checkboxes, radios
		else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
			error.appendTo( element.parent().parent() );
		}
			// Input group, styled file input
		else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
			error.appendTo( element.parent().parent() );
		}
		else {
			error.insertAfter(element);
		}
	},
        
	validClass: "validation-valid-label",
		success: function(label) {
			label.addClass("validation-valid-label").text("Success")
	},
        
	rules: {
		uname:{
			required: true
		},
		
		pwd: {
			required: true
		}
	},
    debug: true,	
		
	submitHandler: function(form) { 
		var base_url = $("#base_url").val();
		var formData = new FormData(form);    
		var l = Ladda.create( document.querySelector( '#LoginBtn' ) );
		
		$.ajax({
			type:"post",
			url: "loginvalidate",
			data:formData,
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			enctype: 'multipart/form-data',
			contentType: false,
			cashe: false,
			processData: false,
			error:function(data){
			return false;
			},
			beforeSend: function() {		// Button with spinner
				l.start(); 		// To spin (for loading spinner)
				$( '#LoginBtn' ).find('.ladda-label').text("Loggin In......");
			},
			success: function(data){    
			data = $.trim(data);
			if($.isNumeric(data)) {  
				if(data==1)
					window.location.href= base_url+'request/home';
				else if(data==2)
					$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Invalid Password...</span></div>');
				else if(data==3)
					$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Unable to Connect to LDAP Server at Comstar. Please try again after some times...</span></div>');
				else if (data==4)
					$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Invalid Username</span></div>');
			}				
			else {  
				window.location.href=data;
			} 
			l.stop();
		}
	});
		return false;	
	}
		
});
});

$(document).on('click', '#entrybtn', function(e) {    
	var test = $("#test").val();  				 				// test = 1 or test = 2
	var value = $("input[name='req_type']:checked").val();  	// value ='new' or 'existing';
	if(value=='new' && test=='1') {    // if test ='1'
		$("#error_msg").html('<div style="color:red;">Project Name Already Exist !!!</div>');
		$("#error_msg").show();
		return false;
	}
	else { 
		$("#request_form").validate({
        ignore: 'input[type=hidden], .select2-input', // ignore hidden fields
        errorClass: 'validation-error-label',
        successClass: 'validation-valid-label',
        highlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
        unhighlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
		rules: {
            req_type:{
				required: true
			},
			cur_process:{
				required: true
			},
			pros_process:{
				required: true
			},
			sel_4fp:{
				required: true
			},
			outcome:{
				required: true
			},
			projdoc:{
				required: true
			}, 
			proj_title:{
				required : {
				depends: function(element) {
				return $('input[name=req_type]:checked').val() == 'New';
				}
				}
			},
			existing_name:{
				required : {
				depends: function(element) {
				return $('input[name=req_type]:checked').val() =='Existing';
				}
				}
			}
		},
       errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 
		if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
			if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
			}
			else {
				error.appendTo( element.parent().parent() );  
			}
		}
		else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
			error.appendTo( element.parent().parent() );                                                
		}
		else {                                                                        
			error.insertAfter(element);
		}
	},
	validClass: "validation-valid-label",
	success: function(label) {
		label.addClass("validation-valid-label").text("Success.")
	},
	submitHandler: function(form) {
		var formData = new FormData(form); 	//alert(formData);
		//var formData = $('#request_form').serializeArray();
		var baseurl= $('#base_url').val();
		var page = $('#pages').val(); 
		$.ajax({
			type:"post",
			url:  baseurl + 'request/newCreation',    
			data:formData,
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			enctype: 'multipart/form-data',				
			 contentType: false,
			cashe: false,
			processData: false, 
			error:function(data){   
				showErrorMessage();
				return false;
			},
			success: function(data){
			data = $.trim(data);
				if($.isNumeric(data)){	
					if(page =='new_request') { 
						showSuccessMessage(baseurl + 'request/new_request');
						return false;
					}
					else if(page =='editcreation') { 
						showSuccessMessage(baseurl + 'request/myreq');
						return false;
					}
				}
				else {
					$("#display").show().html(data);  
					//showErrorMessage(data);  
					return false;
				}
			} 
		});
		return false;	
	}
    });
	}
});

$(document).on('click', '#approve', function(e) {  //alert('hi');   
	$("#Approval_form").validate({     
	errorClass: 'validation-error-label',
	successClass: 'validation-valid-label',
	highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
		$(element).removeClass(errorClass);
	},
	unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
		$(element).removeClass(errorClass);
	},
	
	rules : {
		sts :{
			required : true
		},
		it_remark :{
			required : true
		},
		project_date :{
			required : true
		},
		startdate:{
			required : true
		},
		cmts:{
			required : {
			depends: function(element) {
			return ($('input[name=sts]:checked').val() != 'Yes' || $('input[name=sts]:checked').val() == 'RRITH' );
			}
			}
		},
		devp:{
			required : {
			depends: function(element) {
			return $('input[name=sts]:checked').val() == 'Yes';
			}
			}
		},
		dev_days:{
			required : {
			depends: function(element) {
			return $('input[name=sts]:checked').val() == 'Yes';
			}
			}
		},
		itprio:{
			required : {
			depends: function(element) {
			return $('input[name=sts]:checked').val() == 'ITHA';
			}
			}
		},
		
	},		
	errorPlacement: function(error, element) {
		// Styled checkboxes, radios, bootstrap switch
			if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
				if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
					error.appendTo( element.parent().parent().parent().parent() );
				}
				else {
					error.appendTo( element.parent().parent().parent().parent().parent() );
				}
			}
					// Unstyled checkboxes, radios
			else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
				error.appendTo( element.parent().parent().parent() );
			}
				// Input with icons and Select2
			else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
				error.appendTo( element.parent() );
			}
				// Inline checkboxes, radios
			else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent() );
			}
				// Input group, styled file input
			else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
				error.appendTo( element.parent().parent() );
			}
			else {
				error.insertAfter(element);
			}
		},
	validClass: "validation-valid-label",
		success: function(label) {
		label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
	},
			
	submitHandler: function(form) {
		var formData = new FormData(form);
		var baseurl= $('#base_url').val();
		var page = $('#pages').val();
		
		$.ajax({
			type:"post",
			url: baseurl + 'request/getApproval',
			data:formData,
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			enctype: 'multipart/form-data',				
			contentType: false,
			cashe: false,
			processData: false,
			error:function(data){
				showErrorMessage();
				return false;
			},
			success: function(data){
				data = $.trim(data);
				if($.isNumeric(data)){
					if(page =='hodapprove') { 
						showSuccessMessage(baseurl+"request/hod");
					}
					else if(page =='feasiview') { 
						showSuccessMessage(baseurl + 'request/feasi');
						return false;
					}
					else if(page =='itapprove') { 
						showSuccessMessage(baseurl + 'request/ithead');
						return false;
					}
					else if(page =='projdate') { 
						showSuccessMessage(baseurl + 'request/tentdate');
						return false;
					}
				}
				else{
					$("#display").show().html(data);
					//showErrorMessage(data);
					return false;
				}
			}
		});
			return false;	
	}
	});
});

$(document).on('click', '#remark', function(e) {  //alert('hi');   
	$("#remark_form").validate({     
	errorClass: 'validation-error-label',
	successClass: 'validation-valid-label',
	highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
		$(element).removeClass(errorClass);
	},
	unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
		$(element).removeClass(errorClass);
	},
	
	rules : {
		it_remark :{
			required : true
		}
	},		
	errorPlacement: function(error, element) {
		// Styled checkboxes, radios, bootstrap switch
			if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
				if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
					error.appendTo( element.parent().parent().parent().parent() );
				}
				else {
					error.appendTo( element.parent().parent().parent().parent().parent() );
				}
			}
					// Unstyled checkboxes, radios
			else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
				error.appendTo( element.parent().parent().parent() );
			}
				// Input with icons and Select2
			else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
				error.appendTo( element.parent() );
			}
				// Inline checkboxes, radios
			else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent() );
			}
				// Input group, styled file input
			else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
				error.appendTo( element.parent().parent() );
			}
			else {
				error.insertAfter(element);
			}
		},
	validClass: "validation-valid-label",
		success: function(label) {
		label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
	},
			
	submitHandler: function(form) {
		var formData = new FormData(form);
		var baseurl= $('#base_url').val();
		var page = $('#page').val();
		
		$.ajax({
			type:"post",
			url: baseurl + '/request/getReview',
			data:formData,
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			enctype: 'multipart/form-data',				
			contentType: false,
			cashe: false,
			processData: false,
			error:function(data){
				showErrorMessage();
				return false;
			},
			success: function(data){  // alert(data);
				data = $.trim(data);
				if($.isNumeric(data)){ 
					showSuccessMessage(baseurl+"request/report");
					return false;
				}
				else{
					$("#display").show().html(data);
					//showErrorMessage(data);
					return false;
				}
			}
		});
			return false;	
	}
	});
});

function showSuccessMessage(linkURL){
	swal({
		title: "Success !!!",
		text: "Data saved successfully!!!!",
		confirmButtonColor: "#66BB6A",
		type: "success"
	},
	function(isConfirm){
		if (isConfirm) {
			window.location.href=linkURL;
		}
	});
} 

function showErrorMessage(linkURL){
	swal({
		title: "Error",
		text: linkURL,
		confirmButtonColor: "#66BB6A",
		type: "error"
	});
}

/* portal access request submit */
$(document).on('click', '#portalAccessbtn', function(e) {  
	$("#portal_access_request_form").validate({     
	errorClass: 'validation-error-label',
	successClass: 'validation-valid-label',
	highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
		$(element).removeClass(errorClass);
	},
	unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
		$(element).removeClass(errorClass);
	},
	
	rules : {
		portal_name :{
			required : true
		},
		route_to :{
			required : true
		}
	},		
	errorPlacement: function(error, element) {
		// Styled checkboxes, radios, bootstrap switch
			if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
				if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
					error.appendTo( element.parent().parent().parent().parent() );
				}
				else {
					error.appendTo( element.parent().parent().parent().parent().parent() );
				}
			}
					// Unstyled checkboxes, radios
			else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
				error.appendTo( element.parent().parent().parent() );
			}
				// Input with icons and Select2
			else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
				error.appendTo( element.parent() );
			}
				// Inline checkboxes, radios
			else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent() );
			}
				// Input group, styled file input
			else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
				error.appendTo( element.parent().parent() );
			}
			else {
				error.insertAfter(element);
			}
		},
	validClass: "validation-valid-label",
		success: function(label) {
		label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
	},
			
	submitHandler: function(form) {
		var formData = new FormData(form);
		var baseurl= $('#base_url').val();
		$.ajax({
			type:"post",
			url: baseurl + 'request/submit_to_approve',
			data:formData,
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			enctype: 'multipart/form-data',				
			contentType: false,
			cashe: false,
			processData: false,
			error:function(data){
				showErrorMessage();
				return false;
			},
			success: function(data){  // alert(data);
				data = $.trim(data);
				if($.isNumeric(data)){ 
					showSuccessMessage(baseurl+"request/portal_access_request");
					return false;
				}
				else{
					$("#display").show().html(data);
					//showErrorMessage(data);
					return false;
				}
			}
		});
		return false;	
	}
	})
});