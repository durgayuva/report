$(document).ready(function() {
	
	$('.elastic').autosize();
	
	$(".control-primary").uniform({  	// initializing the Custom Radio Button
		radioClass: 'choice',
		wrapperClass: 'border-primary-800 text-primary-800'
	});
	
	$(".control-danger").uniform({  	// initializing the Custom Radio Button
		radioClass: 'choice',
		wrapperClass: 'border-danger-800 text-danger-800'
	});
	
	$(".control-success").uniform({  
		radioClass: 'choice',
		wrapperClass: 'border-success-800 text-success-800'
	});
	
	$(".control-warning").uniform({  
		radioClass: 'choice',
		wrapperClass: 'border-warning-800 text-warning-800'
	});
	
	$("#sel_4fp").select2({
		placeholder: 'Select 4FP',
		allowClear: true
	});
	
	$("#itprio,#priority").select2({
		placeholder: 'Select Priority',
		allowClear: true
	});
	
	$("#outcome").select2({
		placeholder: 'Select Outcome',
		allowClear: true
	});
	
	$(".multi").select2({
		placeholder: 'Select Department',
		tokenSeparators: [ ',', ' ' ],      // Multiple Select
		allowClear: true
	});
	
	
	$("#multists").select2({
		placeholder: 'Select Status',
		tokenSeparators: [ ',', ' ' ],      // Multiple Select
		allowClear: true
	});
	
	$("#dept").select2({
		placeholder: 'Select Department',
		allowClear: true
	});
	
	$("#existing_name").select2({
		placeholder: 'Select Existing System',
		allowClear: true
	});
	
	$("#devp").select2({
		placeholder: 'Select Developer',
		allowClear: true
	});
	
	$("#route_to").select2({
		placeholder: 'Select Route To',
		allowClear: true
	});
	
	$(document).on('change', '#req_type', function() {    
		if($(this).val()=='New One') {    
			$("#new_system").show();         
			$("#existing_system").hide();
		}
		else {		
			$("#new_system").hide();
			$("#existing_system").show();        
		}
	});   

	$(document).on('change', '#sts', function() {    
		var val = $(this).val();   // alert(val);  return false;
		
		if(val =='HODApproved') {    
			$("#hodcmt").hide();         
		}
		else if(val =='Yes') {    
			$("#devdisp").show();         
			$("#cmtdisp").hide();
		}
		else if(val =='No') { 
			$("#devdisp").hide();
			$("#cmtdisp").show(); 
		}
		else if(val =='ITHead Approved') {     
			$("#headprio").show();         
			$("#itcmt").hide();
		}
		else if(val =='UAT Accepted') {    
			$("#uatdisp").hide();
		}
		else if(val =='Rejected') {    
			$("#uatdisp").show();         
		}
		else {
			$("#hodcmt").show();
			$("#itcmt").show();         
			$("#headprio").hide();
		}		
	}); 
	
	$("#proj_title").blur(function() {    
		var $base_url =$("#base_url").val(); 
		var text=$("#proj_title").val(); 

		if(text =='') {
			text='0';
		}
		var dataString= "title="+encodeURIComponent(text);  
		var promise= sendAjaxFunction($base_url +"request/ajax_loadproject_title",dataString);  
		
		promise.success(function(data) {  
			data = $.trim(data);
			if($.isNumeric(data)) {
			if(data==1) { 
				$("#test").val(data);    
				$("#error_msg").html('<div style="color:red;">Project Name Already Exist !!!</div>');
				$("#error_msg").show();
			}
			else if (data==2) { 
				$("#test").val(data);   
				$("#error_msg").hide();
			}
		}
		});	
	});
	
	$(document).on("change","#dept",function() {
		var val = $(this).val();   // alert(val);
		var dataString ="val="+val;
		var base_url = $("#base_url").val();
		
		var promise = sendAjaxFunction(base_url+'request/ajax_load_Deptchart',dataString);	
		promise.success(function(data) {  
			$("#container4").hide();
			$("#container5").html(data);  	
		}); 
	});
});	

function searchbased()  { 

	var base_url =$("#base_url").val(); 
	var type = $("input[name='req_type']:checked").val();  
	var prio = $("#priority").val();
	
	if(type == undefined) {       
		type='';
	}
	var dataString = "radiotype="+type+"&priority="+prio;
	
	$('body').block({ 
		message: '<span class="text-semibold"><i class="icon-shutter spinner position-left"></i>&nbsp; Processing Data...</span>',
		overlayCSS: {
			backgroundColor: '#fff',
			opacity: 0.8,
			cursor: 'wait'
		},
		css: {
			border: 0,
			padding: '10px 15px',
			color: 'red',
			width: 'auto',
			'-webkit-border-radius': 2,
			'-moz-border-radius': 2,
			backgroundColor: 'transparent'
		}
	});
	
	var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+1,dataString); 
				
	promise.success(function(data) { 
		$('body').unblock();									
		$("#display").html(data);  			
		$('#dataTables').DataTable({   
			responsive: true,
			aLengthMenu: [
				[25, 50, 100, 200, -1],
				[25, 50, 100, 200, "All"]
			],
			dom: 'lBfrtip',
			buttons: [
						
				{
					extend: 'copyHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'csvHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'excelHtml5',
					title: 'PPTM Report'
				}
			]
		});	
	});
}

function reportbased()  { 

	var base_url =$("#base_url").val();
	var type = $("input[name='req_type']:checked").val();  	
	var stats = $("#multists").val();
	var dept = $("#multidept").val();
	
	if(type == undefined) {       
		type='';
	}
	if(stats == null) {       
		stats='';
	}
	if(dept == null) {       
		dept='';
	}
	
	var dataString = "radiotype="+type+"&stats="+stats+"&dept="+dept;   //alert(dataString); return false;
	
	$('body').block({ 
		message: '<span class="text-semibold"><i class="icon-shutter spinner position-left"></i>&nbsp; Processing Data...</span>',
		overlayCSS: {
			backgroundColor: '#fff',
			opacity: 0.8,
			cursor: 'wait'
		},
		css: {
			border: 0,
			padding: '10px 15px',
			color: 'red',
			width: 'auto',
			'-webkit-border-radius': 2,
			'-moz-border-radius': 2,
			backgroundColor: 'transparent'
		}
	});
	
	var promise= sendAjaxFunction(base_url +"/request/ajaxLoadreports",dataString); 
				
	promise.success(function(data) { 
		$('body').unblock();									
		$("#display").html(data);  			
		$('#dataTables').DataTable({   
			responsive: true,
			aLengthMenu: [
				[25, 50, 100, 200, -1],
				[25, 50, 100, 200, "All"]
			],
			dom: 'lBfrtip',
			buttons: [
						
				{
					extend: 'copyHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'csvHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'excelHtml5',
					title: 'PPTM Report'
				}
			]
		});	
	});
}