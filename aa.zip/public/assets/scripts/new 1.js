

		//  **************************   LOGIN PAGE VALIDATION *********************************

//$(document).on('click', '#LogSubBtn', function(e) { 
 
// Onclick event is used once ready function is intialised (onclick is used to refresh ready function and re-load other dom event like onclick, onchange....)

	
	$(function(){  	// $(document).ready(function(){  	While log in this DOM Event should be used 

		$("#LoginValidation").validate({
			
		ignore: 'input[type=hidden], .select2-search__field', // ignore hidden fields
		errorClass: 'validation-error-label',
		successClass: 'validation-valid-label',
		
		highlight: function(element, errorClass) {
			$(element).removeClass(errorClass);
		},
		unhighlight: function(element, errorClass) {
			$(element).removeClass(errorClass);
		},

		errorPlacement: function(error, element) {

			// Styled checkboxes, radios, bootstrap switch
			if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
						
				if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent().parent().parent() );
				}
							
				else {
					error.appendTo( element.parent().parent().parent().parent().parent() );
				}
			
			}

			// Unstyled checkboxes, radios
			else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
				error.appendTo( element.parent().parent().parent() );
			}

			// Input with icons and Select2
			else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
				error.appendTo( element.parent() );
			}

			  // Inline checkboxes, radios
			else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
				error.appendTo( element.parent().parent() );
			}

			// Input group, styled file input
			else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
				error.appendTo( element.parent().parent() );
			}

			else {
				error.insertAfter(element);
			}
		},
        
		validClass: "validation-valid-label",
			success: function(label) {
				label.addClass("validation-valid-label").text("Success")
        },
        
		rules: {
            uname:{
				required: true
			},
			
			pwd: {
				required: true
            }
        },
        
		debug: true,	
		
		submitHandler: function(form) { 
			
			var base_url = $("#base_url").val();
			var formData = new FormData(form);    
			var l = Ladda.create( document.querySelector( '#LoginBtn' ) );
		
		
		$.ajax({
			
			type:"post",
			url: "Login/loginvalidate",
			data:formData,
			enctype: 'multipart/form-data',
			contentType: false,
			cashe: false,
			processData: false,
			
			error:function(data){
			return false;
			},
						
		 beforeSend: function() {		// Button with spinner
				
			l.start(); 		// To spin (for loading spinner)
			$( '#LoginBtn' ).find('.ladda-label').text("Loggin In......");
		},
				
		success: function(data){ //alert(data); 
			data = $.trim(data);
	
			if($.isNumeric(data)) {  
									
				if(data==1)
					window.location.href= base_url+'request/index';
						
				else if(data==2)
				$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Invalid Password...</span></div>');
					
				else if (data==3)
				$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Unable to Connect to LDAP Server at Comstar. Please try again after some times...</span></div>');
			
				else if(data==4)
				$("#showError").html('<div class="alert bg-warning alert-styled-left"><span class="text-semibold">Invalid Username</span></div>');
			}				

			else {  
			window.location.href=data;
			} 
			
			l.stop();
		}
					
				
		});
			return false;	
		}
		
		});

	});


	// ***********************  Validate request.php form with custom radio buttons ***************************
	
	
	$(document).on('click', '#entrybtn', function(e) {  	//alert('hi');
	
	var test = $("#test").val();  				 				// test = 1 or test = 2
	 var value = $("input[name='req_type']:checked").val();  	// value ='new' or 'existing';
	 
	 //alert(value + test);  
	
	if(value=='new' && test=='1') {    // if test ='1'
		$("#error_msg").html('<div style="color:red;"><b>Already Exists !!!!</b></div>');
		$("#error_msg").show();
		return false;
	}
	
	else {     // if test ='2' , i.e After title has been changed  validations and form submission will take place
	
		$("#request_form").validate({
			errorClass: 'validation-error-label',
				
			successClass: 'validation-valid-label',
				
				highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
					$(element).removeClass(errorClass);
				},
				
				unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
					$(element).removeClass(errorClass);
				},
			
			errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 

				if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
					
					if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
							
							error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
					}
						else {
							error.appendTo( element.parent().parent() );  
						}
				}
				
				else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
					error.appendTo( element.parent().parent() );                                                
				}
					else {                                                                        
						error.insertAfter(element);
					}
			},
			
				validClass: "validation-valid-label",
					success: function(label) {
					label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
				},
			
				rules: {
						req_type:{
							required: true
							
						},
						proj_title:{
							required: true
						},
						existing_name:{
							required: true				
						},
						cur_process:{
							required: true
						},
						pros_process:{
							required: true
						},
						sel_4fp:{
							required: true
						},
						outcome:{
							required: true
						},
						proj_doc:{
							required: true
						}
						
				},					
				debug : true,
				submitHandler: function(form) {
				//var formData = new FormData(form); 	//alert(formData);
				var formData = $('#request_form').serializeArray();
				var baseurl= $('#base_url').val();
										
				$.ajax({
					type:"post",
					url:  baseurl + 'Request/add_creation',    
					data:formData,
					enctype: 'multipart/form-data',				
					/* contentType: false,
					cashe: false,
					processData: false, */
					error:function(data){   
						showErrorMessage();
						return false;
					},
					success: function(data){
					data = $.trim(data);
						if($.isNumeric(data)){	
							showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/request");
							return false;
						}
						else {
							$("#display").show().html(data);  
							showErrorMessage(data);  
							return false;
						}
				} 
				});
							
			return false;	
	}
		});
	}
	
	});
	
	
	// **************** HOD APPROVAL VALIDATION *********************** 
	
	$(document).on('click', '#btn_sub', function(e) {  //alert('hi');   
			
		$("#hod_approval_form").validate({     
			
			errorClass: 'validation-error-label',
				
				successClass: 'validation-valid-label',
					
					highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
						$(element).removeClass(errorClass);
					},
					
						unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
							$(element).removeClass(errorClass);
						},
			
							errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 

								if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
									
									if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
											
											error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
									}
										else {
											error.appendTo( element.parent().parent() );  
										}
								}
				
									else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
										error.appendTo( element.parent().parent() );                                                
									}
										else {                                                                        
											error.insertAfter(element);
										}
							},
			
								validClass: "validation-valid-label",
									success: function(label) {
										label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
								},
			
								
								rules : {
									
											sel_status :{
												required : true
											},
									
											hod_comments: {
												required: function(){
													return $('#sel_status').val() !='HODApproved';   // Comment box sholud be shown when status='rejected','Reroute'
												}
												
											}
											
											
								},
								
								submitHandler: function(form) {
										
								var formData = new FormData(form);
								var baseurl= $('#base_url').val();

									
								$.ajax({
											
									type:"post",
									url: baseurl + 'Request/add_creation',
									data:formData,
									enctype: 'multipart/form-data',				
									contentType: false,
									cashe: false,
									processData: false,
										error:function(data){
											showErrorMessage();
												return false;
										},
											
									success: function(data){
										//alert(data);
											data = $.trim(data);
												if($.isNumeric(data)){  	
												
												showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/approval");
													
											}
												else{
													
													$("#view").show().html(data);
													showErrorMessage(data);
														return false;
												}
									}
								});
											
											return false;	
						}
		});
	});
	
	
	// *****************  Validate feasibility check page *********************
	
	
	$(document).on('click', '#sub_btn', function(e) {   //alert('hi');   
	
	var test = $("#test").val();  				 				// test = 1 or test = 2
	var value = $("input[name='req_type']:checked").val();  	// value ='new' or 'existing';
	 
	 //alert(value + test);  
	
	if((value=='new' || value=='existing')&& (test=='1')) {    // if test ='1'
		$("#error_msg").html('<div style="color:red;"><b>Already Exists !!!!</b></div>');
		$("#error_msg").show();
		return false;
	}
	
	else {
	  
	  	$("#feasi_check").validate({  
			
			errorClass: 'validation-error-label',
				
				successClass: 'validation-valid-label',
					
					highlight: function(element, errorClass) {  //alert('a');     // highlight-> Used to highlight the error text ("Field is required")
						$(element).removeClass(errorClass);
					},
					
						unhighlight: function(element, errorClass) {  //alert('b');     //unhighlight-> Used to unhighlight when its success (Success)
							$(element).removeClass(errorClass);
						},
			
							errorPlacement: function(error, element) {  //alert('c');   // errorPlacement-> The place where we wanna place the error text 

								if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
									
									if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) { 
											
											error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
									}
										else { 
											error.appendTo( element.parent().parent() );  
										}
								}
				
									else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {  
										error.appendTo( element.parent().parent() );                                                
									}
										else {                                                                     
											error.insertAfter(element);
										}
							},
			
								validClass: "validation-valid-label",
									success: function(label) {
										label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
								},
			
									rules: {
											
											proj_title:{
												required: true
											},
											existing_name:{
												required: true				
											},
											cur_process:{
												required: true
											},
											pros_process:{
												required: true
											},
											sel_4fp:{
												required: true
											},
											outcome:{
												required: true
											},
										
											feasi_status:{
												required: true
											},
											feasi_comments:{
												required: true
											}
											
									},					
				
								debug:true,
								
								submitHandler: function(form) { 	//alert('fgrg');
										
									var formData = new FormData(form);
									var baseurl= $('#base_url').val(); 
									
									$.ajax({
												
										type:"post",
										url: baseurl + 'Request/add_creation', 
										data:formData,
										enctype: 'multipart/form-data',				
										contentType: false,
										cashe: false,
										processData: false,
											error:function(data){
												showErrorMessage();
													return false;
											},
												
										success: function(data) {
											//alert(data);
												data = $.trim(data);
													if($.isNumeric(data)){  	
													
													showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/feasi");
														
												}
													else{
														
														$("#view").show().html(data);
														showErrorMessage(data);
															return false;
													}
										}
									});
												
												return false;	
								}
		});
	}
	});
	

	// ******************** Validating the IT HEAD APPROVAL PAGE  ***********************************

	$(document).on('click', '#sub_button', function(e) {  //alert('hi');   
	 
		$("#ithead_approval_form").validate({
			
			errorClass: 'validation-error-label',
				
				successClass: 'validation-valid-label',
					
					highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
						$(element).removeClass(errorClass);
					},
					
						unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
							$(element).removeClass(errorClass);
						},
			
							errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 

								if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
									
									if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
											
											error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
									}
										else {
											error.appendTo( element.parent().parent() );  
										}
								}
				
									else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
										error.appendTo( element.parent().parent() );                                                
									}
										else {                                                                        
											error.insertAfter(element);
										}
							},
			
								validClass: "validation-valid-label",
									success: function(label) {
										label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
								},
			
									rules: {
								
											priority:{
												required: true
												
											},
											app_status:{
												required: true
											},
											head_comments:{
												required: true				
											}
									},					
				

								submitHandler: function(form) {
										
									var formData = new FormData(form);
									var baseurl= $('#base_url').val(); 
									
									//var dataString = "?ids="+id; 
										$.ajax({
													
													type:"post",
													url:baseurl + 'Request/add_creation',
													data:formData,
													enctype: 'multipart/form-data',				
													contentType: false,
													cashe: false,
													processData: false,
														error:function(data){
															showErrorMessage();
																return false;
														},
															
													success: function(data){
														//alert(data);
															data = $.trim(data);
																if($.isNumeric(data)){	
																
																showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/headapproval");
																		return false;
															}
																else{
																		
																	$("#view").show().html(data);
																	showErrorMessage(data);
																		return false;
																}
													}
												});
													
													return false;	
								}
		});
	});
	
	
	
	// *************************  Validating the project tentative Date ************************
	
	$(document).on('click', '#btn_submit', function(e) {     // alert('hi');   
	  
	
		$("#project_tentative_form").validate({
			
			errorClass: 'validation-error-label',
				
				successClass: 'validation-valid-label',
					
					highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
						$(element).removeClass(errorClass);
					},
					
						unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
							$(element).removeClass(errorClass);
						},
			
							errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 

								if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
									
									if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
											
											error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
									}
										else {
											error.appendTo( element.parent().parent() );  
										}
								}
				
									else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
										error.appendTo( element.parent().parent() );                                                
									}
										else {                                                                        
											error.insertAfter(element);
										}
							},
			
								validClass: "validation-valid-label",
									success: function(label) {
										label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
								},
			
									rules: {
								
											project_date:{
												required: true
												
											},
											
											app_status:{
												required: true
											},

											comments:{
												required: true				
											}
									},					
				

								submitHandler: function(form) {
									
									var formData = new FormData(form);
									var baseurl= $('#base_url').val(); 
									
									$.ajax({
										type:"post",
										url:baseurl + 'Request/add_creation',
										data:formData,
										enctype: 'multipart/form-data',				
										contentType: false,
										cashe: false,
										processData: false,
											error:function(data){
												showErrorMessage();
													return false;
											},
												
										success: function(data){
											//alert(data);
												data = $.trim(data);
													if($.isNumeric(data)){	
													
													showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/tentdate");
															return false;
												}
													else {
												
														$("#view").show().html(data);
														showErrorMessage(data);
															return false;
													}
										}
										
									});
													
													return false;	
								}
		});
		
	});
	
 
 // ************************* To Edit My Request Page *********************
	
	$(document).on('click', '#edit_btn', function(e) {   // alert('jk');
	
	var test = $("#test").val();  				 				// test = 1 or test = 2
	var value = $("input[name='req_type']:checked").val();  	// value ='new' or 'existing';
	 
	 //alert(value + test);  
	
	if(value=='new' && test=='1') {    // if test ='1'
		$("#error_msg").html('<div style="color:red;"><b>Already Exists !!!!</b></div>');
		$("#error_msg").show();
		return false;
	}
	
	else {     // if test ='2' , i.e After title has been changed  validations and form submission will take place
	
		$("#Editmyrequest").validate({
			errorClass: 'validation-error-label',
				
				successClass: 'validation-valid-label',
					
					highlight: function(element, errorClass) {      // highlight-> Used to highlight the error text ("Field is required")
						$(element).removeClass(errorClass);
					},
					
						unhighlight: function(element, errorClass) {      //unhighlight-> Used to unhighlight when its success (Success)
							$(element).removeClass(errorClass);
						},
			
							errorPlacement: function(error, element) {     // errorPlacement-> The place where we wanna place the error text 

								if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
									
									if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
											
											error.appendTo( element.parent().parent().parent().parent()); 	// CUSTOM RADIO BUTTON PLACEMENT
									}
										else {
											error.appendTo( element.parent().parent() );  
										}
								}
				
									else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
										error.appendTo( element.parent().parent() );                                                
									}
										else {                                                                        
											error.insertAfter(element);
										}
							},
			
								validClass: "validation-valid-label",
									success: function(label) {
										label.addClass("validation-valid-label").text("Success.");      //if the enter value is valid ("success")
								},
			
									rules: {
											req_type:{
												required: true
												
											},
											proj_title:{
												required: true
											},
											existing_name:{
												required: true				
											},
											cur_process:{
												required: true
											},
											pros_process:{
												required: true
											},
											sel_4fp:{
												required: true
											},
											outcome:{
												required: true
											},
											
									},					
				

								submitHandler: function(form) {
									
								var formData = new FormData(form); 	//alert(formData);
								var baseurl= $('#base_url').val();
								
										$.ajax({
											
											type:"post",
											url:  baseurl + 'Request/add_creation',     // url: 'Request/addrequest_creation', 
											data:formData,
											enctype: 'multipart/form-data',				
											contentType: false,
											cashe: false,
											processData: false,
												error:function(data){   
													showErrorMessage();
														return false;
												},
													
											success: function(data){
												
													data = $.trim(data);
														if($.isNumeric(data)){	
														
												showSuccessMessage("http://172.20.2.244/working/app_request/request/view_pages/myreq");
																return false;

													}
													
														else{
													
														$("#display").show().html(data);   // - To display mail ($message in html format)
															showErrorMessage(data);  
																return false;
														}
											} 
										});
													
													return false;	
								}
		});
	}	
	});
	
	
	
	
 
	/*   //  ************************** To Edit My Request Page  Without Validation************************ 

$(document).on('click', '#edit_btn', function(e) {     
	  
	  	var pagename =$('#page_return').val(); 
		
		var id = ($(this).val());  // button value = 1  
			
	  // alert(id);
										
			var formData = new FormData($("#Editmyrequest")[0]); 

// $("#Editmyrequest")[0])  -> [0] -> To get the values in the array format in the controller without validations and cannot alert formdata here 

				var baseurl= $('#base_url').val(); 
			
					var project_title_id =$("#projtitle_id").val();   	//alert(project_title_id);
			
						var proj_desc = $("#existing_name").val(); 		//alert (proj_desc);
			
						$.ajax({
									type:"post",
									url: baseurl +'Request/add_creation/'+pagename+'/'+id+'/'+project_title_id+'/'+proj_desc, 
									data:formData,
									enctype: 'multipart/form-data',				
									contentType: false,
									cashe: false,
									processData: false,
										error:function(data){
											showErrorMessage();
												return false;
										},
											
									success: function(data){
										//alert(data);
											data = $.trim(data);
												if($.isNumeric(data)){	
												
												showSuccessMessage("http://172.20.4.244/working/app_request/request/view_pages/myreq");
														return false;
											}
												else{
											
													showErrorMessage(data);  
														return false;
												}
									}
									
								});
									
									return false;	
	
		});
 */

	
	function showSuccessMessage(linkURL){
		
		swal({
				title: "Success !!!",
				text: "Data saved successfully!!!!",
				confirmButtonColor: "#66BB6A",
				type: "success"
			},
			function(isConfirm){
				if (isConfirm) {
					window.location.href=linkURL;
				}
			});
	} 

	function showErrorMessage(linkURL){
		
		swal({
			title: "Error",
			text: linkURL,
			confirmButtonColor: "#66BB6A",
			type: "error"
		});
	}