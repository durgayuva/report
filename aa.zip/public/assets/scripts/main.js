/* ------------------------------------------------------------------------------
*
*  # Main javascript function 
*
*  Author: R.SUGANYA
*  Version: 1.0.1
*  Latest update: March 24, 2018
*
* ---------------------------------------------------------------------------- */

function LoadMasters() {
	var base_url =$("#base_url").val();    		
	var page =$("#pages").val();
	
	$('body').block({ 
		message: '<span class="text-semibold"><i class="icon-shutter spinner position-left"></i>&nbsp; Processing Data...</span>',
		overlayCSS: {
			backgroundColor: '#fff',
			opacity: 0.8,
			cursor: 'wait'
		},
		css: {
			border: 0,
			padding: '10px 15px',
			color: 'red',
			width: 'auto',
			'-webkit-border-radius': 2,
			'-moz-border-radius': 2,
			backgroundColor: 'transparent'
		}
	});
	
	switch(page) { 
		case 'myreq' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+1); 
		break;
	
		case 'hod' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+2); 
		break;
		
		case 'feasi' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+4); 
		break;
		
		case 'ithead' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+5); 
		break;
		
		case 'tentdate' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+6); 
		break;
		
		case 'UAT' :
			var promise= sendAjaxFunction(base_url +"request/ajaxload_myrecords/"+7); 
		break;
		
	}
	promise.success(function(data) { 
		$('body').unblock();									
		$("#display").html(data);  			
		$('#dataTables').DataTable({   
			responsive: true,
			aLengthMenu: [
				[25, 50, 100, 200, -1],
				[25, 50, 100, 200, "All"]
			],
			dom: 'lBfrtip',
			buttons: [
				{
					extend: 'copyHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'csvHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'excelHtml5',
					title: 'PPTM Report'
				}
			]
		});	
	});
}

function loadReports() {
	var base_url =$("#base_url").val();    		
	
	$('body').block({ 
		message: '<span class="text-semibold"><i class="icon-shutter spinner position-left"></i>&nbsp; Processing Data...</span>',
		overlayCSS: {
			backgroundColor: '#fff',
			opacity: 0.8,
			cursor: 'wait'
		},
		css: {
			border: 0,
			padding: '10px 15px',
			color: 'red',
			width: 'auto',
			'-webkit-border-radius': 2,
			'-moz-border-radius': 2,
			backgroundColor: 'transparent'
		}
	});
	var promise= sendAjaxFunction(base_url +"request/ajaxLoadreports"); 
	promise.success(function(data) { 
		$('body').unblock();									
		$("#display").html(data);  			
		$('#dataTables').DataTable({   
			responsive: true,
			aLengthMenu: [
				[25, 50, 100, 200, -1],
				[25, 50, 100, 200, "All"]
			],
			dom: 'lBfrtip',
			buttons: [
				{
					extend: 'copyHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'csvHtml5',
					title: 'PPTM Report'
				},
				{
					extend: 'excelHtml5',
					title: 'PPTM Report'
				}
			]
		});	
	});
}

function sendAjaxFunction(url,dataString) {
	
	return $.ajax({
		url	:url,
		type: 'POST',
		dataType:"text",
		data:dataString,
		headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
		error:function(){
			alert ("An Error as Occured...");
			$('body').unblock();
			return false;
		}
	});
}